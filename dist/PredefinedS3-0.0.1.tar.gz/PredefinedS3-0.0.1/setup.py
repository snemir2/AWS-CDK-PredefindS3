from setuptools import setup, find_packages

setup(
    name="PredefinedS3",
    description="Commonly used S3 bucket configurations",
    packages=['PredefinedS3'],
    version="0.0.1"
)