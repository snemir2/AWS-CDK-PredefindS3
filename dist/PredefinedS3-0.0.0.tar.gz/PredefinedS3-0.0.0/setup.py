from setuptools import setup, find_packages
from PredefinedS3 import __version__
setup(
    name="PredefinedS3",
    description="Commonly used S3 bucket configurations",
    packages=['PredefinedS3'],
  
)